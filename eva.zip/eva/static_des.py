import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os


def plot_statistics_summary(csv_file='statistics_summary.csv'):
    """
    绘制统计摘要图表
    """
    #读取CSV文件
    df = pd.read_csv(csv_file)

    #过滤掉Frames和Mean Distance(px)指标，因为它们与其他指标数量级不同
    df_filtered = df[~df['Metric'].isin(['Frames', 'Mean Distance(px)'])].copy()

    if len(df_filtered) == 0:
        print("错误：过滤后没有数据可绘制！")
        return

    #创建输出目录
    output_dir = 'statistics_visualization'
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    #设置中文字体
    plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial']  #使用黑体或Arial
    plt.rcParams['axes.unicode_minus'] = False  #解决负号显示问题

    #提取过滤后的数据
    metrics = df_filtered['Metric'].values
    averages = pd.to_numeric(df_filtered['Average'].values)
    std_devs = pd.to_numeric(df_filtered['Std Dev'].values)
    mins = pd.to_numeric(df_filtered['Min'].values)
    maxs = pd.to_numeric(df_filtered['Max'].values)
    medians = pd.to_numeric(df_filtered['Median'].values)

    print(f"处理的指标: {list(metrics)}")
    print(f"平均值: {averages}")

    #要指标柱状图（平均值）
    fig, axes = plt.subplots(2, 2, figsize=(16, 12))
    axes = axes.flatten()

    #主要指标平均值柱状图
    colors = ['#FF6B6B', '#4ECDC4', '#45B7D1']

    bars = axes[0].bar(metrics, averages, color=colors[:len(metrics)], alpha=0.8, edgecolor='black')
    axes[0].set_title('主要指标平均值比较', fontsize=14, fontweight='bold')
    axes[0].set_ylabel('平均值', fontsize=12)
    axes[0].tick_params(axis='x', rotation=15)
    axes[0].grid(True, alpha=0.3, linestyle='--')

    #在柱子上添加数值标签
    for i, (bar, avg) in enumerate(zip(bars, averages)):
        height = bar.get_height()
        axes[0].text(bar.get_x() + bar.get_width() / 2., height + 0.02,
                     f'{avg:.3f}', ha='center', va='bottom', fontsize=10)

    #平均值与标准差（带误差线的柱状图）
    x_pos = np.arange(len(metrics))
    bars = axes[1].bar(x_pos, averages, yerr=std_devs, capsize=5,
                       color=colors[:len(metrics)], alpha=0.8, edgecolor='black')
    axes[1].set_title('平均值与标准差', fontsize=14, fontweight='bold')
    axes[1].set_ylabel('值', fontsize=12)
    axes[1].set_xticks(x_pos)
    axes[1].set_xticklabels(metrics, rotation=15)
    axes[1].grid(True, alpha=0.3, linestyle='--')

    #范围图
    width = 0.25

    axes[2].bar(x_pos - width, mins, width, label='最小值', color='#FF9999', alpha=0.8)
    axes[2].bar(x_pos, medians, width, label='中位数', color='#99CCFF', alpha=0.8)
    axes[2].bar(x_pos + width, maxs, width, label='最大值', color='#99FF99', alpha=0.8)

    axes[2].set_title('最小值、中位数、最大值比较', fontsize=14, fontweight='bold')
    axes[2].set_ylabel('值', fontsize=12)
    axes[2].set_xticks(x_pos)
    axes[2].set_xticklabels(metrics, rotation=15)
    axes[2].legend(loc='upper left')
    axes[2].grid(True, alpha=0.3, linestyle='--')

    #标准差雷达图
    #标准化数据到0-1范围以便于比较
    std_normalized = std_devs / std_devs.max()

    #准备雷达图数据
    N = len(metrics)
    values = np.concatenate((std_normalized, [std_normalized[0]]))

    #计算每个角度
    angles = np.linspace(0, 2 * np.pi, N, endpoint=False).tolist()
    angles += angles[:1]

    #创建雷达图
    ax_radar = axes[3]
    ax_radar = plt.subplot(2, 2, 4, polar=True)
    ax_radar.plot(angles, values, 'o-', linewidth=2, color='#FF6B6B')
    ax_radar.fill(angles, values, alpha=0.25, color='#FF6B6B')

    #设置标签
    ax_radar.set_xticks(angles[:-1])
    ax_radar.set_xticklabels(metrics, fontsize=10)
    ax_radar.set_yticklabels([])
    ax_radar.set_title('标准差相对比较雷达图', fontsize=14, fontweight='bold', pad=20)
    ax_radar.grid(True)

    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'statistics_summary_comprehensive.png'), dpi=300, bbox_inches='tight')
    plt.close()

    #详细比较图
    fig, axes = plt.subplots(1, 3, figsize=(16, 5))
    axes = axes.flatten()

    for i, metric in enumerate(metrics[:3]):  #显示3个指标
        if i >= len(axes):
            break

        ax = axes[i]

        #创建柱状图
        x_labels = ['平均值', '最小值', '中位数', '最大值']
        values = [averages[i], mins[i], medians[i], maxs[i]]
        colors_single = ['#4ECDC4', '#FF9999', '#99CCFF', '#99FF99']

        bars = ax.bar(x_labels, values, color=colors_single, alpha=0.8, edgecolor='black')
        ax.set_title(f'{metric}', fontsize=12, fontweight='bold')
        ax.set_ylabel('值', fontsize=10)
        ax.grid(True, alpha=0.3, linestyle='--')

        #添加数值标签
        for j, (bar, val) in enumerate(zip(bars, values)):
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width() / 2., height + height * 0.01,
                    f'{val:.3f}', ha='center', va='bottom', fontsize=9)

        #添加标准差信息
        ax.text(0.02, 0.95, f'标准差: {std_devs[i]:.3f}',
                transform=ax.transAxes, fontsize=10,
                bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))


    for i in range(len(metrics), len(axes)):
        axes[i].set_visible(False)

    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'statistics_detailed_comparison.png'), dpi=300, bbox_inches='tight')
    plt.close()

    #创建热力图显示各指标的关系
    fig, ax = plt.subplots(figsize=(10, 8))

    #创建数据矩阵
    data_matrix = np.array([averages, std_devs, mins, maxs, medians])

    #创建热力图
    im = ax.imshow(data_matrix, cmap='YlOrRd', aspect='auto')

    #设置坐标轴
    ax.set_xticks(np.arange(len(metrics)))
    ax.set_yticks(np.arange(5))
    ax.set_xticklabels(metrics, rotation=15)
    ax.set_yticklabels(['平均值', '标准差', '最小值', '最大值', '中位数'])

    #添加数值标签
    for i in range(5):
        for j in range(len(metrics)):
            text = ax.text(j, i, f'{data_matrix[i, j]:.2f}',
                           ha="center", va="center", color="black", fontsize=10)

    ax.set_title('指标统计热力图', fontsize=14, fontweight='bold')
    plt.colorbar(im, ax=ax)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'statistics_heatmap.png'), dpi=300, bbox_inches='tight')
    plt.close()

    #创建箱线图样式的可视化
    fig, ax = plt.subplots(figsize=(10, 8))

    #为每个指标创建"箱线图"样式数据
    for i, metric in enumerate(metrics):
        #使用最小值、中位数、平均值、最大值
        data_points = [mins[i], medians[i], averages[i], maxs[i]]

        #绘制箱线图元素
        box = ax.boxplot([data_points], positions=[i], widths=0.6, patch_artist=True)

        #设置箱线图颜色
        box['boxes'][0].set_facecolor(colors[i % len(colors)])
        box['boxes'][0].set_alpha(0.7)

        #添加指标名称
        ax.text(i, maxs[i] + (maxs[i] - mins[i]) * 0.05, metric,
                ha='center', va='bottom', fontsize=10, rotation=0)

    ax.set_xlabel('指标', fontsize=12)
    ax.set_ylabel('值范围', fontsize=12)
    ax.set_title('各指标值范围分布（箱线图样式）', fontsize=14, fontweight='bold')
    ax.set_xticks([])  #移除x轴刻度，因为我们用文本标注了
    ax.grid(True, alpha=0.3, linestyle='--')

    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'statistics_boxplot_style.png'), dpi=300, bbox_inches='tight')
    plt.close()

    #创建平均值与标准差的关系散点图
    fig, ax = plt.subplots(figsize=(10, 8))

    #创建散点图
    scatter = ax.scatter(averages, std_devs, s=200, c=range(len(metrics)),
                         cmap='viridis', alpha=0.7, edgecolors='black')

    #为每个点添加标签
    for i, metric in enumerate(metrics):
        ax.annotate(metric, (averages[i], std_devs[i]),
                    xytext=(5, 5), textcoords='offset points', fontsize=10)

    ax.set_xlabel('平均值', fontsize=12)
    ax.set_ylabel('标准差', fontsize=12)
    ax.set_title('平均值与标准差关系散点图', fontsize=14, fontweight='bold')
    ax.grid(True, alpha=0.3, linestyle='--')

    #添加颜色条
    plt.colorbar(scatter, ax=ax, label='指标索引')

    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'statistics_scatter_plot.png'), dpi=300, bbox_inches='tight')
    plt.close()

    #创建成功率和精度对比图
    fig, ax = plt.subplots(figsize=(12, 8))

    #找出成功率和精度的索引
    success_rate_idx = None
    precision_idx = None
    mean_iou_idx = None

    for i, metric in enumerate(metrics):
        if 'Success Rate' in metric:
            success_rate_idx = i
        elif 'Precision' in metric:
            precision_idx = i
        elif 'Mean IoU' in metric:
            mean_iou_idx = i

    #如果有成功率和精度，创建对比图
    if success_rate_idx is not None and precision_idx is not None:
        #准备数据
        metric_names = [metrics[precision_idx], metrics[success_rate_idx]]
        if mean_iou_idx is not None:
            metric_names.append(metrics[mean_iou_idx])

        avg_values = [averages[precision_idx], averages[success_rate_idx]]
        std_values = [std_devs[precision_idx], std_devs[success_rate_idx]]
        min_values = [mins[precision_idx], mins[success_rate_idx]]
        max_values = [maxs[precision_idx], maxs[success_rate_idx]]

        if mean_iou_idx is not None:
            avg_values.append(averages[mean_iou_idx])
            std_values.append(std_devs[mean_iou_idx])
            min_values.append(mins[mean_iou_idx])
            max_values.append(maxs[mean_iou_idx])

        x_pos = np.arange(len(metric_names))
        width = 0.2

        #绘制分组柱状图
        ax.bar(x_pos - width * 1.5, avg_values, width, label='平均值', color='#4ECDC4', alpha=0.8)
        ax.bar(x_pos - width / 2, min_values, width, label='最小值', color='#FF9999', alpha=0.8)
        ax.bar(x_pos + width / 2, max_values, width, label='最大值', color='#99FF99', alpha=0.8)

        #添加误差线表示标准差
        ax.errorbar(x_pos - width * 1.5, avg_values, yerr=std_values, fmt='none',
                    ecolor='black', capsize=5, capthick=1)

        ax.set_xlabel('指标', fontsize=12)
        ax.set_ylabel('值', fontsize=12)
        ax.set_title('性能指标对比', fontsize=14, fontweight='bold')
        ax.set_xticks(x_pos)
        ax.set_xticklabels(metric_names, fontsize=11)
        ax.legend(loc='upper right')
        ax.grid(True, alpha=0.3, linestyle='--')

        #添加数值标签
        for i, (avg, min_val, max_val) in enumerate(zip(avg_values, min_values, max_values)):
            ax.text(i - width * 1.5, avg + 0.02, f'{avg:.3f}', ha='center', va='bottom', fontsize=10)
            ax.text(i - width / 2, min_val + 0.02, f'{min_val:.3f}', ha='center', va='bottom', fontsize=10)
            ax.text(i + width / 2, max_val + 0.02, f'{max_val:.3f}', ha='center', va='bottom', fontsize=10)

        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, 'performance_metrics_comparison.png'), dpi=300, bbox_inches='tight')
        plt.close()

    #7. 创建性能指标趋势图
    fig, ax = plt.subplots(figsize=(10, 6))

    #假设我们想按平均值排序
    sorted_indices = np.argsort(averages)[::-1]  #从高到低排序
    sorted_metrics = metrics[sorted_indices]
    sorted_averages = averages[sorted_indices]
    sorted_stds = std_devs[sorted_indices]

    #绘制趋势线
    x_pos = np.arange(len(sorted_metrics))
    ax.plot(x_pos, sorted_averages, 'o-', linewidth=2, markersize=8, color='#FF6B6B', label='平均值')

    #添加误差线
    ax.errorbar(x_pos, sorted_averages, yerr=sorted_stds, fmt='o',
                capsize=5, capthick=1, color='#FF6B6B', alpha=0.7)

    #填充区域表示标准差范围
    ax.fill_between(x_pos, sorted_averages - sorted_stds, sorted_averages + sorted_stds,
                    alpha=0.2, color='#FF6B6B')

    ax.set_xlabel('指标', fontsize=12)
    ax.set_ylabel('平均值', fontsize=12)
    ax.set_title('性能指标趋势（按平均值排序）', fontsize=14, fontweight='bold')
    ax.set_xticks(x_pos)
    ax.set_xticklabels(sorted_metrics, rotation=15, fontsize=11)
    ax.legend(loc='best')
    ax.grid(True, alpha=0.3, linestyle='--')

    #添加数值标签
    for i, (avg, std_val) in enumerate(zip(sorted_averages, sorted_stds)):
        ax.text(i, avg + std_val + 0.02, f'{avg:.3f}±{std_val:.3f}',
                ha='center', va='bottom', fontsize=9)

    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'performance_trend.png'), dpi=300, bbox_inches='tight')
    plt.close()

    print(f"\n图表已保存到 '{output_dir}' 目录:")
    print(f"1. statistics_summary_comprehensive.png - 综合统计图表")
    print(f"2. statistics_detailed_comparison.png - 详细比较图表")
    print(f"3. statistics_heatmap.png - 统计热力图")
    print(f"4. statistics_boxplot_style.png - 箱线图样式图表")
    print(f"5. statistics_scatter_plot.png - 散点图")
    if success_rate_idx is not None and precision_idx is not None:
        print(f"6. performance_metrics_comparison.png - 性能指标对比图")
    print(f"7. performance_trend.png - 性能指标趋势图")

    #8. 创建数据汇总表
    print(f"\n过滤后的统计数据汇总（已忽略Frames和Mean Distance(px)指标）:")
    print("=" * 80)
    print(f"{'指标':<25} {'平均值':<10} {'标准差':<10} {'最小值':<10} {'最大值':<10} {'中位数':<10}")
    print("-" * 80)
    for i, metric in enumerate(metrics):
        print(
            f"{metric:<25} {averages[i]:<10.4f} {std_devs[i]:<10.4f} {mins[i]:<10.4f} {maxs[i]:<10.4f} {medians[i]:<10.4f}")


if __name__ == "__main__":
    #执行绘图函数
    plot_statistics_summary(csv_file='./tracking_evaluation_results/statistics_summary.csv')
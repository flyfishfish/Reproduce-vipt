import numpy as np
import matplotlib.pyplot as plt
import os
import glob
import pandas as pd


def parse_file(filename):
    data = []
    try:
        with open(filename, 'r') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue

                # Try different delimiters
                if ',' in line:
                    values = list(map(float, line.split(',')))
                elif '\t' in line:
                    values = list(map(float, line.split('\t')))
                else:
                    values = list(map(float, line.split()))

                if len(values) >= 4:  # Ensure at least 4 values (x,y,w,h)
                    data.append(values[:4])

    except Exception as e:
        print(f"  Warning: Error parsing file {filename}: {e}")

    return np.array(data)


def calculate_iou(box1, box2, format='xywh'):
    """
    Calculate IoU of two bounding boxes
    box: [x, y, w, h] or [x1, y1, x2, y2]
    format: 'xywh' or 'xyxy'
    """
    if format == 'xywh':
        # Convert to xyxy format
        x1 = box1[0] - box1[2] / 2
        y1 = box1[1] - box1[3] / 2
        x2 = box1[0] + box1[2] / 2
        y2 = box1[1] + box1[3] / 2

        x1_p = box2[0] - box2[2] / 2
        y1_p = box2[1] - box2[3] / 2
        x2_p = box2[0] + box2[2] / 2
        y2_p = box2[1] + box2[3] / 2
    else:
        x1, y1, x2, y2 = box1
        x1_p, y1_p, x2_p, y2_p = box2

    # Calculate intersection area
    inter_x1 = max(x1, x1_p)
    inter_y1 = max(y1, y1_p)
    inter_x2 = min(x2, x2_p)
    inter_y2 = min(y2, y2_p)

    # Check if there is intersection
    if inter_x2 <= inter_x1 or inter_y2 <= inter_y1:
        return 0.0

    # Calculate intersection and union areas
    inter_area = (inter_x2 - inter_x1) * (inter_y2 - inter_y1)
    box1_area = (x2 - x1) * (y2 - y1)
    box2_area = (x2_p - x1_p) * (y2_p - y1_p)
    union_area = box1_area + box2_area - inter_area

    # Calculate IoU
    iou = inter_area / union_area if union_area > 0 else 0.0
    return iou


def calculate_center_distance(box1, box2):
    """
    Calculate Euclidean distance between centers of two bounding boxes
    box: [x, y, w, h]
    """
    # Extract center coordinates
    cx1, cy1 = box1[0], box1[1]
    cx2, cy2 = box2[0], box2[1]

    # Calculate Euclidean distance
    distance = np.sqrt((cx1 - cx2) ** 2 + (cy1 - cy2) ** 2)
    return distance


def evaluate_tracking_performance(ground_truth, predictions, iou_threshold=0.5, distance_threshold=20):
    """
    Evaluate tracking performance with both IoU-based and distance-based metrics
    """
    if len(ground_truth) == 0 or len(predictions) == 0:
        return None

    if len(ground_truth) != len(predictions):
        print(f"  Warning: Data length mismatch! Ground truth: {len(ground_truth)}, Predictions: {len(predictions)}")
        min_len = min(len(ground_truth), len(predictions))
        ground_truth = ground_truth[:min_len]
        predictions = predictions[:min_len]

    num_frames = len(ground_truth)
    ious = []
    center_distances = []

    # Calculate per frame
    for gt, pred in zip(ground_truth, predictions):
        # Calculate IoU
        iou = calculate_iou(gt, pred)
        ious.append(iou)

        # Calculate center distance
        distance = calculate_center_distance(gt, pred)
        center_distances.append(distance)

    # IoU-based metrics (Success Rate)
    success_iou_05 = np.sum([1 if iou >= iou_threshold else 0 for iou in ious])
    success_iou_03 = np.sum([1 if iou >= 0.3 else 0 for iou in ious])
    success_iou_07 = np.sum([1 if iou >= 0.7 else 0 for iou in ious])
    success_iou_09 = np.sum([1 if iou >= 0.9 else 0 for iou in ious])

    success_rate_05 = success_iou_05 / num_frames
    success_rate_03 = success_iou_03 / num_frames
    success_rate_07 = success_iou_07 / num_frames
    success_rate_09 = success_iou_09 / num_frames

    # Distance-based metrics (Precision)
    precision_20 = np.sum([1 if dist <= distance_threshold else 0 for dist in center_distances]) / num_frames

    # Also calculate precision at other common thresholds
    precision_10 = np.sum([1 if dist <= 10 else 0 for dist in center_distances]) / num_frames
    precision_05 = np.sum([1 if dist <= 5 else 0 for dist in center_distances]) / num_frames

    # Calculate mean center distance
    mean_distance = np.mean(center_distances)
    median_distance = np.median(center_distances)

    # Calculate mean and median IoU
    mean_iou = np.mean(ious) if len(ious) > 0 else 0
    median_iou = np.median(ious) if len(ious) > 0 else 0

    # IoU standard deviation
    std_iou = np.std(ious) if len(ious) > 0 else 0

    # Distance standard deviation
    std_distance = np.std(center_distances) if len(center_distances) > 0 else 0

    # Calculate success rates at different IoU thresholds (for curve)
    thresholds = np.linspace(0, 1, 101)
    success_at_thresholds = {}
    for thresh in thresholds:
        # 使用普通浮点数作为键，而不是numpy浮点数
        threshold_key = float(thresh)
        success_at_thresholds[threshold_key] = np.mean([1 if iou >= thresh else 0 for iou in ious]) if len(
            ious) > 0 else 0

    # Calculate precision at different distance thresholds (for curve)
    distance_thresholds = np.linspace(0, 50, 101)
    precision_at_thresholds = {}
    for thresh in distance_thresholds:
        # 使用普通浮点数作为键，而不是numpy浮点数
        threshold_key = float(thresh)
        precision_at_thresholds[threshold_key] = np.mean(
            [1 if dist <= thresh else 0 for dist in center_distances]) if len(center_distances) > 0 else 0

    return {
        'num_frames': num_frames,

        # Distance-based metrics (Precision)
        'precision_20': precision_20,  # 中心点距离 ≤ 20像素的比例
        'precision_10': precision_10,  # 中心点距离 ≤ 10像素的比例
        'precision_05': precision_05,  # 中心点距离 ≤ 5像素的比例
        'mean_distance': mean_distance,
        'median_distance': median_distance,
        'std_distance': std_distance,

        # IoU-based metrics (Success Rate)
        'success_rate_05': success_rate_05,  # IoU ≥ 0.5的比例
        'success_rate_03': success_rate_03,  # IoU ≥ 0.3的比例
        'success_rate_07': success_rate_07,  # IoU ≥ 0.7的比例
        'success_rate_09': success_rate_09,  # IoU ≥ 0.9的比例
        'mean_iou': mean_iou,
        'median_iou': median_iou,
        'std_iou': std_iou,

        # For plotting curves
        'success_at_thresholds': success_at_thresholds,
        'precision_at_thresholds': precision_at_thresholds,
        'ious': ious,
        'center_distances': center_distances
    }


def create_summary_table(results_dict):
    """
    Create summary table with both precision and success rate metrics
    """
    summary_data = []

    for name, results in results_dict.items():
        summary_data.append({
            'Dataset': name,
            'Frames': str(results['num_frames']),  # Convert to string for easier formatting

            # Precision metrics (distance-based)
            'Precision(≤20px)': f"{results['precision_20']:.4f}",
            'Precision(≤10px)': f"{results['precision_10']:.4f}",
            'Precision(≤5px)': f"{results['precision_05']:.4f}",
            'Mean Distance(px)': f"{results['mean_distance']:.2f}",
            'Median Distance(px)': f"{results['median_distance']:.2f}",
            'Distance Std(px)': f"{results['std_distance']:.2f}",

            # Success rate metrics (IoU-based)
            'Success Rate(IoU≥0.5)': f"{results['success_rate_05']:.4f}",
            'Success Rate(IoU≥0.3)': f"{results['success_rate_03']:.4f}",
            'Success Rate(IoU≥0.7)': f"{results['success_rate_07']:.4f}",
            'Success Rate(IoU≥0.9)': f"{results['success_rate_09']:.4f}",
            'Mean IoU': f"{results['mean_iou']:.4f}",
            'Median IoU': f"{results['median_iou']:.4f}",
            'IoU Std': f"{results['std_iou']:.4f}",
        })

    return pd.DataFrame(summary_data)


def visualize_all_results(results_dict, output_dir='tracking_evaluation_results'):
    """
    Visualize all tracking evaluation results
    """
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # Create summary charts
    create_summary_charts(results_dict, output_dir)

    # Create individual charts for each dataset
    for name, results in results_dict.items():
        create_dataset_charts(name, results, output_dir)


def create_summary_charts(results_dict, output_dir):
    """
    Create summary charts for top and bottom datasets
    """
    # Get all datasets sorted by success rate
    all_datasets = list(results_dict.keys())

    # Sort by success rate (IoU≥0.5)
    sorted_datasets = sorted(all_datasets, key=lambda x: results_dict[x]['success_rate_05'], reverse=True)

    # Take top 10 datasets
    top_datasets = sorted_datasets[:10]

    # Take bottom 10 datasets (lowest success rate)
    if len(sorted_datasets) >= 10:
        bottom_datasets = sorted_datasets[-10:]
    else:
        bottom_datasets = sorted_datasets  # If less than 10, use all

    print(f"Creating summary charts for top 10 and bottom 10 datasets")

    # 1. Main metrics comparison bar chart (Top 10)
    create_metrics_bar_chart(top_datasets, results_dict, output_dir, 'top_10_metrics.png', 'Top 10 Datasets')

    # 2. Main metrics comparison bar chart (Bottom 10)
    if len(bottom_datasets) > 0 and bottom_datasets != top_datasets:
        create_metrics_bar_chart(bottom_datasets, results_dict, output_dir, 'bottom_10_metrics.png',
                                 'Bottom 10 Datasets')

    # 3. Success rate vs IoU threshold curve (Top 10)
    create_performance_curves(top_datasets, results_dict, output_dir, 'top_10_performance_curves.png',
                              'Top 10 Datasets')

    # 4. Success rate vs IoU threshold curve (Bottom 10)
    if len(bottom_datasets) > 0 and bottom_datasets != top_datasets:
        create_performance_curves(bottom_datasets, results_dict, output_dir, 'bottom_10_performance_curves.png',
                                  'Bottom 10 Datasets')


def create_metrics_bar_chart(datasets, results_dict, output_dir, filename, title_suffix):
    """
    Create bar chart for metrics comparison
    """
    metrics = ['Precision(≤20px)', 'Success Rate(IoU≥0.5)', 'Mean Distance(px)', 'Mean IoU']
    metric_keys = ['precision_20', 'success_rate_05', 'mean_distance', 'mean_iou']

    fig, axes = plt.subplots(2, 2, figsize=(16, 10))
    axes = axes.flatten()

    for idx, (metric, key) in enumerate(zip(metrics, metric_keys)):
        values = [results_dict[name][key] for name in datasets]

        axes[idx].bar(datasets, values, color=plt.cm.Set3(np.linspace(0, 1, len(datasets))))
        axes[idx].set_title(f'{metric} Comparison - {title_suffix}')
        axes[idx].set_ylabel(metric)

        # Set appropriate y-limits
        if 'Distance' in metric:
            max_value = max(values) * 1.1
            axes[idx].set_ylim(0, max_value)
        else:
            axes[idx].set_ylim(0, 1.05)

        axes[idx].tick_params(axis='x', rotation=45)

        # Add value labels
        for i, v in enumerate(values):
            if 'Distance' in metric:
                axes[idx].text(i, v + max_value * 0.02, f'{v:.2f}', ha='center', va='bottom', fontsize=9)
            else:
                axes[idx].text(i, v + 0.02, f'{v:.3f}', ha='center', va='bottom', fontsize=9)

    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, filename), dpi=300, bbox_inches='tight')
    plt.close()


def create_performance_curves(datasets, results_dict, output_dir, filename, title_suffix):
    """
    Create performance curves (success rate and precision)
    """
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))

    # Success rate curve
    thresholds = np.linspace(0, 1, 101)

    for name in datasets:  # Show all specified datasets
        results = results_dict[name]
        success_rates = []

        # Ensure thresholds match dictionary keys
        for threshold in thresholds:
            threshold_key = float(threshold)
            if threshold_key in results['success_at_thresholds']:
                success_rates.append(results['success_at_thresholds'][threshold_key])
            else:
                # Find closest threshold
                closest_key = min(results['success_at_thresholds'].keys(),
                                  key=lambda x: abs(x - threshold_key))
                success_rates.append(results['success_at_thresholds'][closest_key])

        ax1.plot(thresholds, success_rates, label=name, linewidth=2)

    ax1.set_xlabel('IoU Threshold')
    ax1.set_ylabel('Success Rate')
    ax1.set_title(f'Success Rate vs IoU Threshold - {title_suffix}')
    ax1.legend(loc='lower left', fontsize='small')
    ax1.grid(True, alpha=0.3)
    ax1.set_xlim(0, 1)
    ax1.set_ylim(0, 1)

    # Precision curve
    distance_thresholds = np.linspace(0, 50, 101)

    for name in datasets:  # Show all specified datasets
        results = results_dict[name]
        precisions = []

        # Ensure thresholds match dictionary keys
        for threshold in distance_thresholds:
            threshold_key = float(threshold)
            if threshold_key in results['precision_at_thresholds']:
                precisions.append(results['precision_at_thresholds'][threshold_key])
            else:
                # Find closest threshold
                closest_key = min(results['precision_at_thresholds'].keys(),
                                  key=lambda x: abs(x - threshold_key))
                precisions.append(results['precision_at_thresholds'][closest_key])

        ax2.plot(distance_thresholds, precisions, label=name, linewidth=2)

    ax2.set_xlabel('Distance Threshold (pixels)')
    ax2.set_ylabel('Precision')
    ax2.set_title(f'Precision vs Distance Threshold - {title_suffix}')
    ax2.legend(loc='lower right', fontsize='small')
    ax2.grid(True, alpha=0.3)
    ax2.set_xlim(0, 50)
    ax2.set_ylim(0, 1)

    # Add vertical lines for common thresholds
    ax2.axvline(x=20, color='red', linestyle='--', alpha=0.5, label='20px threshold')
    ax2.axvline(x=10, color='green', linestyle='--', alpha=0.5, label='10px threshold')

    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, filename), dpi=300, bbox_inches='tight')
    plt.close()


def create_dataset_charts(dataset_name, results, output_dir):
    """
    Create individual charts for a dataset
    """
    sub_dir = os.path.join(output_dir, dataset_name)
    if not os.path.exists(sub_dir):
        os.makedirs(sub_dir)

    ious = results['ious']
    distances = results['center_distances']

    # Create figure with 2x2 subplots
    fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(14, 10))

    # 1. IoU distribution histogram
    n1, bins1, patches1 = ax1.hist(ious, bins=50, alpha=0.7, color='skyblue', edgecolor='black')
    ax1.axvline(x=0.5, color='red', linestyle='--', linewidth=2, label='IoU=0.5 threshold')
    ax1.axvline(x=results['mean_iou'], color='green', linestyle='-', linewidth=2,
                label=f'Mean IoU={results["mean_iou"]:.3f}')
    ax1.set_xlabel('IoU')
    ax1.set_ylabel('Frequency')
    ax1.set_title(f'{dataset_name} - IoU Distribution')
    ax1.legend()
    ax1.grid(True, alpha=0.3)

    # 2. Center distance distribution histogram
    n2, bins2, patches2 = ax2.hist(distances, bins=50, alpha=0.7, color='lightcoral', edgecolor='black')
    ax2.axvline(x=20, color='red', linestyle='--', linewidth=2, label='20px threshold')
    ax2.axvline(x=results['mean_distance'], color='green', linestyle='-', linewidth=2,
                label=f'Mean Distance={results["mean_distance"]:.1f}px')
    ax2.set_xlabel('Center Distance (pixels)')
    ax2.set_ylabel('Frequency')
    ax2.set_title(f'{dataset_name} - Center Distance Distribution')
    ax2.legend()
    ax2.grid(True, alpha=0.3)

    # 3. Success rate vs IoU threshold curve
    thresholds = np.linspace(0, 1, 101)
    success_rates = []
    for threshold in thresholds:
        success_rates.append(results['success_at_thresholds'][float(threshold)])

    ax3.plot(thresholds, success_rates, 'b-', linewidth=2)
    ax3.fill_between(thresholds, success_rates, alpha=0.2, color='blue')
    ax3.axvline(x=0.5, color='red', linestyle='--', linewidth=1, label='IoU=0.5 threshold')
    ax3.set_xlabel('IoU Threshold')
    ax3.set_ylabel('Success Rate')
    ax3.set_title(f'{dataset_name} - Success Rate vs IoU Threshold')
    ax3.grid(True, alpha=0.3)
    ax3.legend()
    ax3.set_xlim(0, 1)
    ax3.set_ylim(0, 1)

    # 4. Precision vs Distance threshold curve
    distance_thresholds = np.linspace(0, 50, 101)
    precisions = []
    for threshold in distance_thresholds:
        precisions.append(results['precision_at_thresholds'][float(threshold)])

    ax4.plot(distance_thresholds, precisions, 'r-', linewidth=2)
    ax4.fill_between(distance_thresholds, precisions, alpha=0.2, color='red')
    ax4.axvline(x=20, color='blue', linestyle='--', linewidth=1, label='20px threshold')
    ax4.axvline(x=10, color='green', linestyle='--', linewidth=1, label='10px threshold')
    ax4.set_xlabel('Distance Threshold (pixels)')
    ax4.set_ylabel('Precision')
    ax4.set_title(f'{dataset_name} - Precision vs Distance Threshold')
    ax4.grid(True, alpha=0.3)
    ax4.legend()
    ax4.set_xlim(0, 50)
    ax4.set_ylim(0, 1)

    # Add overall statistics text
    stats_text = f"""Statistics:
Frames: {results['num_frames']}
Success Rate(IoU≥0.5): {results['success_rate_05']:.2%}
Precision(≤20px): {results['precision_20']:.2%}
Mean IoU: {results['mean_iou']:.3f}
Mean Distance: {results['mean_distance']:.1f}px
"""

    plt.figtext(0.02, 0.02, stats_text, fontsize=10,
                bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.8))

    plt.tight_layout(rect=[0, 0.1, 1, 1])  # Leave space at bottom for text
    plt.savefig(os.path.join(sub_dir, 'tracking_performance.png'), dpi=300, bbox_inches='tight')
    plt.close()


def save_detailed_results(results_dict, output_dir='tracking_evaluation_results'):
    """
    Save detailed tracking evaluation results (CSV only)
    """
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # 1. Create summary table
    summary_df = create_summary_table(results_dict)

    # 2. Add average row at the bottom
    numeric_columns = summary_df.columns[summary_df.columns != 'Dataset']

    # Calculate average for each numeric column
    avg_row = {'Dataset': 'Average'}
    for col in numeric_columns:
        # Convert string values to float for averaging
        numeric_values = pd.to_numeric(summary_df[col], errors='coerce')
        avg_value = numeric_values.mean()

        # Format based on column type
        if 'Frames' in col:
            avg_row[col] = f"{avg_value:.1f}"
        elif 'Distance' in col or 'Std' in col:
            avg_row[col] = f"{avg_value:.2f}"
        else:
            avg_row[col] = f"{avg_value:.4f}"

    # Append average row to the DataFrame
    summary_with_avg = summary_df.copy()
    summary_with_avg = pd.concat([summary_with_avg, pd.DataFrame([avg_row])], ignore_index=True)

    # 3. Save summary as CSV
    summary_with_avg.to_csv(os.path.join(output_dir, 'summary.csv'), index=False, encoding='utf-8-sig')

    # 4. Save detailed analysis and statistics
    save_analysis_results(results_dict, output_dir)


def save_analysis_results(results_dict, output_dir):
    """
    Save additional analysis and statistics (CSV only)
    """
    # Calculate overall statistics
    datasets = list(results_dict.keys())

    # Initialize lists for statistics
    metrics_data = {
        'Precision(≤20px)': [],
        'Success Rate(IoU≥0.5)': [],
        'Mean IoU': [],
        'Mean Distance(px)': [],
        'Frames': []
    }

    for name, results in results_dict.items():
        metrics_data['Precision(≤20px)'].append(results['precision_20'])
        metrics_data['Success Rate(IoU≥0.5)'].append(results['success_rate_05'])
        metrics_data['Mean IoU'].append(results['mean_iou'])
        metrics_data['Mean Distance(px)'].append(results['mean_distance'])
        metrics_data['Frames'].append(results['num_frames'])

    # Create statistics DataFrame
    stats_rows = []
    for metric, values in metrics_data.items():
        if len(values) > 0:
            stats_rows.append({
                'Metric': metric,
                'Average': f"{np.mean(values):.4f}",
                'Std Dev': f"{np.std(values):.4f}" if len(values) > 1 else "0.0000",
                'Min': f"{np.min(values):.4f}",
                'Max': f"{np.max(values):.4f}",
                'Median': f"{np.median(values):.4f}"
            })

    stats_df = pd.DataFrame(stats_rows)

    # Save statistics as CSV
    stats_df.to_csv(os.path.join(output_dir, 'statistics_summary.csv'), index=False, encoding='utf-8-sig')

    # Create ranking DataFrame (sorted by success rate)
    ranking_data = []
    for name, results in results_dict.items():
        ranking_data.append({
            'Dataset': name,
            'Success Rate(IoU≥0.5)': results['success_rate_05'],
            'Precision(≤20px)': results['precision_20'],
            'Mean IoU': results['mean_iou'],
            'Mean Distance(px)': results['mean_distance'],
            'Frames': results['num_frames']
        })

    ranking_df = pd.DataFrame(ranking_data)
    ranking_df = ranking_df.sort_values('Success Rate(IoU≥0.5)', ascending=False)
    ranking_df.insert(0, 'Rank', range(1, len(ranking_df) + 1))  # Add rank column

    # Save ranking as CSV
    ranking_df.to_csv(os.path.join(output_dir, 'ranking.csv'), index=False, encoding='utf-8-sig')

    # 5. Save detailed data for each dataset
    for name, results in results_dict.items():
        sub_dir = os.path.join(output_dir, name)
        if not os.path.exists(sub_dir):
            os.makedirs(sub_dir)

        # Frame-by-frame data
        frame_data = pd.DataFrame({
            'frame_id': range(len(results['ious'])),
            'iou': results['ious'],
            'center_distance': results['center_distances'],
            'success_iou_0.5': [1 if iou >= 0.5 else 0 for iou in results['ious']],
            'precision_20px': [1 if dist <= 20 else 0 for dist in results['center_distances']],
        })

        frame_data.to_csv(os.path.join(sub_dir, 'frame_data.csv'), index=False, encoding='utf-8-sig')

        # Statistics
        stats_df = pd.DataFrame([
            ['Number of Frames', results['num_frames']],

            # Distance-based metrics
            ['Precision (≤20px)', f"{results['precision_20']:.6f}"],
            ['Precision (≤10px)', f"{results['precision_10']:.6f}"],
            ['Precision (≤5px)', f"{results['precision_05']:.6f}"],
            ['Mean Distance (px)', f"{results['mean_distance']:.6f}"],
            ['Median Distance (px)', f"{results['median_distance']:.6f}"],
            ['Distance Std (px)', f"{results['std_distance']:.6f}"],

            # IoU-based metrics
            ['Success Rate (IoU≥0.5)', f"{results['success_rate_05']:.6f}"],
            ['Success Rate (IoU≥0.3)', f"{results['success_rate_03']:.6f}"],
            ['Success Rate (IoU≥0.7)', f"{results['success_rate_07']:.6f}"],
            ['Success Rate (IoU≥0.9)', f"{results['success_rate_09']:.6f}"],
            ['Mean IoU', f"{results['mean_iou']:.6f}"],
            ['Median IoU', f"{results['median_iou']:.6f}"],
            ['IoU Std', f"{results['std_iou']:.6f}"],
        ], columns=['Metric', 'Value'])

        stats_df.to_csv(os.path.join(sub_dir, 'statistics.csv'), index=False, encoding='utf-8-sig')


def main():
    """
    Main function: Automatically discover and evaluate all tracking datasets
    """
    print("=" * 80)
    print("Object Tracking Batch Evaluation Tool")
    print("=" * 80)

    # Configuration parameters
    iou_threshold = 0.5  # For success rate
    distance_threshold = 20  # For precision (in pixels)
    output_dir = 'tracking_evaluation_results'

    # Specify prediction and ground truth directories
    prediction_dir = './deep_rgbt'  # Prediction files directory
    ground_truth_dir = './extra'  # Ground truth directory

    print(f"\nConfiguration:")
    print(f"  Success Rate IoU Threshold: {iou_threshold}")
    print(f"  Precision Distance Threshold: {distance_threshold} pixels")
    print(f"  Output Directory: {output_dir}")
    print(f"  Prediction Directory: {prediction_dir}")
    print(f"  Ground Truth Directory: {ground_truth_dir}")

    # Check if directories exist
    if not os.path.exists(prediction_dir):
        print(f"Error: Prediction directory '{prediction_dir}' does not exist!")
        return

    if not os.path.exists(ground_truth_dir):
        print(f"Error: Ground truth directory '{ground_truth_dir}' does not exist!")
        return

    # Automatically discover file pairs
    print(f"\nScanning for files...")

    # Use the simplified discovery function for your specific structure
    eva_dir = "./eva"
    prediction_dir_eva = os.path.join(eva_dir, "deep_rgbt")
    ground_truth_dir_eva = os.path.join(eva_dir, "extra")

    # Check if eva directory structure exists
    if os.path.exists(eva_dir):
        print(f"Found eva directory structure, using it...")
        prediction_dir = prediction_dir_eva
        ground_truth_dir = ground_truth_dir_eva

    file_pairs = []

    # Get prediction files
    prediction_files = sorted(glob.glob(os.path.join(prediction_dir, "*.txt")))
    ground_truth_files = sorted(glob.glob(os.path.join(ground_truth_dir, "*_init.txt")))

    print(f"Prediction files: {len(prediction_files)}")
    print(f"Ground truth files: {len(ground_truth_files)}")

    # Create ground truth mapping
    gt_map = {}
    for gt_file in ground_truth_files:
        filename = os.path.basename(gt_file)
        # Remove "_init.txt" suffix
        base_name = filename[:-9]  # "_init.txt" has 9 characters
        gt_map[base_name] = gt_file

    # Match files
    for pred_file in prediction_files:
        pred_filename = os.path.basename(pred_file)
        # Remove ".txt" suffix
        base_name = pred_filename[:-4]  # ".txt" has 4 characters

        gt_file = gt_map.get(base_name)

        if gt_file:
            file_pairs.append((base_name, pred_file, gt_file))
            print(f"  ✓ {base_name:30s}")
        else:
            print(f"  ✗ {base_name:30s}: No ground truth found")

    print(f"\nMatched {len(file_pairs)}/{len(prediction_files)} datasets")

    if not file_pairs:
        print("\nError: No matching file pairs found!")
        return

    # Evaluate all dataset pairs
    results_dict = {}
    for dataset_name, pred_path, gt_path in file_pairs:
        print(f"\nEvaluating {dataset_name}...")

        ground_truth = parse_file(gt_path)
        predictions = parse_file(pred_path)

        if len(ground_truth) == 0:
            print(f"  Warning: Ground truth file is empty or cannot be parsed!")
            continue

        if len(predictions) == 0:
            print(f"  Warning: Prediction file is empty or cannot be parsed!")
            continue

        if len(ground_truth) != len(predictions):
            print(f"  Warning: Frame count mismatch! GT: {len(ground_truth)}, Pred: {len(predictions)}")
            min_len = min(len(ground_truth), len(predictions))
            ground_truth = ground_truth[:min_len]
            predictions = predictions[:min_len]
            print(f"  Using first {min_len} frames for evaluation")

        results = evaluate_tracking_performance(ground_truth, predictions, iou_threshold, distance_threshold)
        if results:
            results_dict[dataset_name] = results
            print(f"  ✓ Success Rate (IoU≥0.5): {results['success_rate_05']:.4f}")
            print(f"  ✓ Precision (≤20px): {results['precision_20']:.4f}")

    if not results_dict:
        print("\nError: No datasets were successfully evaluated!")
        return

    # Visualize results
    print("\nGenerating visualizations...")
    visualize_all_results(results_dict, output_dir)

    # Save detailed results
    print("\nSaving result files...")
    save_detailed_results(results_dict, output_dir)

    # Calculate and display overall statistics
    print("\n" + "=" * 80)
    print("Overall Statistics (averaged across all datasets):")
    print("=" * 80)

    avg_precision_20 = np.mean([results['precision_20'] for results in results_dict.values()])
    avg_success_rate_05 = np.mean([results['success_rate_05'] for results in results_dict.values()])
    avg_mean_iou = np.mean([results['mean_iou'] for results in results_dict.values()])
    avg_mean_distance = np.mean([results['mean_distance'] for results in results_dict.values()])

    print(f"\nAverage Precision (≤20px): {avg_precision_20:.4f}")
    print(f"Average Success Rate (IoU≥0.5): {avg_success_rate_05:.4f}")
    print(f"Average Mean IoU: {avg_mean_iou:.4f}")
    print(f"Average Mean Distance: {avg_mean_distance:.2f} px")

    # Completion message
    print("\n" + "=" * 80)
    print("Tracking Evaluation Complete!")
    print("=" * 80)

    print(f"\nResult files saved to '{output_dir}/' directory:")
    print(f"  1. summary.csv - Summary results with average row")
    print(f"  2. statistics_summary.csv - Overall statistics")
    print(f"  3. ranking.csv - Dataset ranking by success rate")
    print(f"  4. Performance curves - Success rate and precision curves (top 10 and bottom 10)")
    print(f"  5. Individual dataset folders - Detailed results and charts for each dataset")


if __name__ == "__main__":
    main()
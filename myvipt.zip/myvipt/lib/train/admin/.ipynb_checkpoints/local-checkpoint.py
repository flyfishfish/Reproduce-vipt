class EnvironmentSettings:
    def __init__(self):
        self.workspace_dir = 'D:/code/ViPT-main'    # Base directory for saving network checkpoints.
        self.tensorboard_dir = 'D:/code/ViPT-main/tensorboard'    # Directory for tensorboard files.
        self.pretrained_networks = 'D:/code/ViPT-main/pretrained_networks'
        self.got10k_val_dir = 'D:/code/ViPT-main/data/got10k/val'
        self.lasot_lmdb_dir = 'D:/code/ViPT-main/data/lasot_lmdb'
        self.got10k_lmdb_dir = 'D:/code/ViPT-main/data/got10k_lmdb'
        self.trackingnet_lmdb_dir = 'D:/code/ViPT-main/data/trackingnet_lmdb'
        self.coco_lmdb_dir = 'D:/code/ViPT-main/data/coco_lmdb'
        self.coco_dir = 'D:/code/ViPT-main/data/coco'
        self.lasot_dir = 'D:/code/ViPT-main/data/lasot'
        self.got10k_dir = 'D:/code/ViPT-main/data/got10k/train'
        self.trackingnet_dir = 'D:/code/ViPT-main/data/trackingnet'
        self.depthtrack_dir = 'D:/code/ViPT-main/data/depthtrack/train'
        self.lasher_dir = 'D:/code/ViPT-main/data/lasher/trainingset'
        self.visevent_dir = 'D:/code/ViPT-main/data/visevent/train'

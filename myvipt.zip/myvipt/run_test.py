#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
一键运行 ViPT RGB-T 跟踪测试脚本
支持多种RGB-T数据集测试
"""

import os
import sys
import subprocess
import time
import argparse
import platform
from pathlib import Path


def check_environment():
    """检查运行环境"""
    print("🔍 检查运行环境...")
    
    # 检查Python版本
    python_version = sys.version_info
    print(f"  Python版本: {python_version.major}.{python_version.minor}.{python_version.micro}")
    
    # 检查CUDA可用性
    try:
        import torch
        cuda_available = torch.cuda.is_available()
        cuda_version = torch.version.cuda if cuda_available else "N/A"
        print(f"  CUDA可用: {cuda_available}")
        if cuda_available:
            print(f"  CUDA版本: {cuda_version}")
            print(f"  GPU数量: {torch.cuda.device_count()}")
            for i in range(torch.cuda.device_count()):
                print(f"    GPU {i}: {torch.cuda.get_device_name(i)}")
    except ImportError:
        print("  ❌ PyTorch未安装")
        return False
    
    # 检查OpenCV
    try:
        import cv2
        print(f"  OpenCV版本: {cv2.__version__}")
    except ImportError:
        print("  ⚠️ OpenCV未安装")
    
    return True


def check_dataset_paths():
    """检查数据集路径"""
    print("\n📁 检查数据集路径...")
    
    # 这里列出您在test_rgbt_mgpus.py中定义的数据集路径
    dataset_paths = {
        'LasHeR': 'D:/code/LasHeR0327/TestingSet/testingset',
        'RGBT234': '/root/autodl-tmp/data/RGBT234',
        'GTOT': '/home/lz/Videos/GTOT',
        'VTUAVST': '/mnt/6196b16a-836e-45a4-b6f2-641dca0991d0/VTUAV/test/short-term',
        'VTUAVLT': '/mnt/6196b16a-836e-45a4-b6f2-641dca0991d0/VTUAV/test/long-term'
    }
    
    for name, path in dataset_paths.items():
        if os.path.exists(path):
            print(f"  ✅ {name}: {path}")
        else:
            print(f"  ❌ {name}: 路径不存在 - {path}")
    
    return True


def run_single_test(dataset_name, yaml_name="deep_rgbt", script_name="vipt", 
                   gpu_ids="0", threads=4, epoch=60, debug=0):
    """
    运行单个数据集测试
    """
    print(f"\n{'=' * 80}")
    print(f"🚀 开始测试: {dataset_name} 数据集")
    print(f"📋 配置信息:")
    print(f"   - 配置文件: {yaml_name}")
    print(f"   - 跟踪器: {script_name}")
    print(f"   - GPU设备: {gpu_ids}")
    print(f"   - 线程数: {threads}")
    print(f"   - Epoch: {epoch}")
    print(f"{'=' * 80}")

    # 设置环境变量
    env = os.environ.copy()
    env['CUDA_VISIBLE_DEVICES'] = gpu_ids
    
    # 根据平台调整命令
    python_cmd = sys.executable
    if platform.system() == "Windows":
        # Windows上可能需要调整路径
        python_cmd = "python"

    # 构建命令 - 添加更多参数
    cmd = [
        python_cmd,
        "./RGBT_workspace/test_rgbt_mgpus.py",
        "--script_name", script_name,
        "--yaml_name", yaml_name,
        "--dataset_name", dataset_name,
        "--threads", str(threads),
        "--num_gpus", str(len(gpu_ids.split(','))),
        "--epoch", str(epoch),
        "--debug", str(debug),
        "--mode", "parallel"
    ]

    print(f"📝 执行命令:")
    print(f"   {' '.join(cmd)}")
    print(f"📂 工作目录: {os.getcwd()}")

    start_time = time.time()
    
    try:
        # 运行测试，实时输出日志
        process = subprocess.Popen(
            cmd, 
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            universal_newlines=True
        )
        
        # 实时打印输出
        print("\n📊 测试输出:")
        print("-" * 40)
        for line in process.stdout:
            print(line.strip())
        print("-" * 40)
        
        # 等待进程完成
        process.wait()
        end_time = time.time()
        
        if process.returncode == 0:
            print(f"\n✅ {dataset_name} 测试成功完成!")
            print(f"⏰ 耗时: {end_time - start_time:.2f} 秒")
            return True
        else:
            print(f"\n❌ {dataset_name} 测试失败! 返回码: {process.returncode}")
            return False
            
    except FileNotFoundError:
        print(f"\n❌ 找不到测试脚本: ./RGBT_workspace/test_rgbt_mgpus.py")
        return False
    except Exception as e:
        print(f"\n❌ {dataset_name} 测试出现异常: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


def run_all_tests(datasets, yaml_name, script_name, gpu_ids, threads, 
                 epoch, debug, stop_on_error=True):
    """
    运行所有指定的测试
    """
    print(f"\n🌟 开始批量测试 {len(datasets)} 个数据集")
    
    results = []
    total_start = time.time()
    
    for i, dataset in enumerate(datasets, 1):
        print(f"\n📅 进度: {i}/{len(datasets)}")
        
        success = run_single_test(
            dataset, yaml_name, script_name, gpu_ids, threads, epoch, debug
        )
        
        results.append((dataset, success))
        
        # 如果失败且设置了停止，则中断
        if not success and stop_on_error:
            print(f"\n⛔ 由于 {dataset} 测试失败，停止后续测试")
            break
            
        # 如果不是最后一个测试，可以添加延时
        if i < len(datasets):
            print(f"\n⏳ 等待3秒后开始下一个测试...")
            time.sleep(3)
    
    return results, total_start


def print_summary(results, total_start):
    """打印测试总结"""
    total_end = time.time()
    total_time = total_end - total_start
    
    print(f"\n{'=' * 80}")
    print("📊 测试总结报告")
    print(f"{'=' * 80}")
    
    # 统计结果
    passed = sum(1 for _, success in results if success)
    failed = len(results) - passed
    
    print(f"📈 测试统计:")
    print(f"   ✅ 成功: {passed}/{len(results)}")
    print(f"   ❌ 失败: {failed}/{len(results)}")
    print(f"   ⏰ 总耗时: {total_time:.2f} 秒")
    
    print(f"\n📋 详细结果:")
    for dataset, success in results:
        status = "✅ 通过" if success else "❌ 失败"
        print(f"   {dataset:15} : {status}")
    
    # 保存结果到文件
    save_summary(results, total_time)
    
    print(f"\n💾 详细日志已保存到: test_summary.txt")
    print(f"{'=' * 80}")
    
    return passed == len(results)


def save_summary(results, total_time):
    """保存测试总结到文件"""
    with open("test_summary.txt", "w", encoding="utf-8") as f:
        f.write("=" * 80 + "\n")
        f.write("ViPT RGB-T 跟踪测试报告\n")
        f.write(f"生成时间: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write("=" * 80 + "\n\n")
        
        f.write("测试统计:\n")
        passed = sum(1 for _, success in results if success)
        f.write(f"  成功: {passed}/{len(results)}\n")
        f.write(f"  失败: {len(results) - passed}/{len(results)}\n")
        f.write(f"  总耗时: {total_time:.2f} 秒\n\n")
        
        f.write("详细结果:\n")
        for dataset, success in results:
            status = "通过" if success else "失败"
            f.write(f"  {dataset}: {status}\n")


def main():
    parser = argparse.ArgumentParser(
        description='一键运行 ViPT RGB-T 跟踪测试',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  # 测试所有数据集
  python run_vipt_test.py --all
  
  # 只测试LasHeR
  python run_vipt_test.py --datasets RGBT234
  
  # 使用特定GPU和配置
  python run_vipt_test.py --all --gpus 0,1 --yaml ostrack_ce_ep60_prompt
  
  # 调试模式
  python run_vipt_test.py --datasets LasHeR --debug 1
        """
    )
    
    # 数据集选项
    dataset_group = parser.add_mutually_exclusive_group()
    dataset_group.add_argument('--all', action='store_true', 
                             help='测试所有可用数据集')
    dataset_group.add_argument('--datasets', nargs='+', 
                             choices=['LasHeR', 'RGBT234', 'GTOT', 'VTUAVST', 'VTUAVLT'],
                             default=['RGBT234'],
                             help='指定要测试的数据集列表')
    
    # 配置选项
    parser.add_argument('--yaml', type=str, default='deep_rgbt',
                       help='配置文件名称')
    parser.add_argument('--script', type=str, default='vipt',
                       help='跟踪器脚本名称')
    parser.add_argument('--gpus', type=str, default='0',
                       help='使用的GPU ID，用逗号分隔，例如: 0,1')
    parser.add_argument('--threads', type=int, default=8,
                       help='并行线程数')
    parser.add_argument('--epoch', type=int, default=60,
                       help='模型epoch')
    parser.add_argument('--debug', type=int, default=0,
                       help='调试模式 (0=关闭, 1=开启)')
    parser.add_argument('--continue_on_error', action='store_true',
                       help='测试失败时继续运行下一个测试')
    parser.add_argument('--check_env', action='store_true',
                       help='运行前检查环境')
    
    args = parser.parse_args()
    
    print("🚀 ViPT RGB-T 跟踪测试一键运行脚本")
    print("📅", time.strftime("%Y-%m-%d %H:%M:%S"))
    print()
    
    # 确定要测试的数据集
    if args.all:
        datasets = ['LasHeR', 'RGBT234', 'GTOT', 'VTUAVST', 'VTUAVLT']
    else:
        datasets = args.datasets
    
    print("📋 配置信息:")
    print(f"   - 测试数据集: {', '.join(datasets)}")
    print(f"   - 配置文件: {args.yaml}")
    print(f"   - 跟踪器: {args.script}")
    print(f"   - GPU设备: {args.gpus}")
    print(f"   - 线程数: {args.threads}")
    print(f"   - Epoch: {args.epoch}")
    print(f"   - 调试模式: {args.debug}")
    print()
    
    # 环境检查
    if args.check_env:
        if not check_environment():
            print("❌ 环境检查失败，请先修复环境问题")
            return
        
        check_dataset_paths()
        print()
        
        continue_test = input("环境检查完成，是否继续测试? (y/n): ")
        if continue_test.lower() != 'y':
            print("测试已取消")
            return
    
    # 运行测试
    results, total_start = run_all_tests(
        datasets=datasets,
        yaml_name=args.yaml,
        script_name=args.script,
        gpu_ids=args.gpus,
        threads=args.threads,
        epoch=args.epoch,
        debug=args.debug,
        stop_on_error=not args.continue_on_error
    )
    
    # 输出总结
    all_passed = print_summary(results, total_start)
    
    # 退出码
    sys.exit(0 if all_passed else 1)


if __name__ == "__main__":
    main()
import os


def list_all_files(directory):
    """
    显示文件夹下所有文件和子目录文件，排除.pyc文件
    """
    # 如果目录为空，使用当前目录
    if not directory:
        directory = os.getcwd()

    # 检查目录是否存在
    if not os.path.exists(directory):
        print(f"错误: 目录 '{directory}' 不存在")
        return

    if not os.path.isdir(directory):
        print(f"错误: '{directory}' 不是一个目录")
        return

    print(f"目录 '{directory}' 下的所有文件 (排除.pyc文件):")
    print("=" * 50)

    # 使用os.walk遍历所有子目录
    for root, dirs, files in os.walk(directory):
        # 计算当前目录相对于起始目录的层级
        level = root.replace(directory, '').count(os.sep)
        indent = '  ' * level

        # 打印当前目录
        print(f"{indent}📁 {os.path.basename(root) if level > 0 else os.path.basename(root)}/")

        # 打印当前目录下的所有文件，排除.pyc文件
        sub_indent = '  ' * (level + 1)
        for file in files:
            # 跳过.pyc文件
            if file.endswith('.pyc'):
                continue
            print(f"{sub_indent}📄 {file}")


if __name__ == "__main__":
    # 获取用户输入的目录路径
    target_directory = input("请输入要遍历的目录路径 (留空则使用当前目录): ").strip()

    # 调用函数显示所有文件
    list_all_files(target_directory)
conda install -y pytorch==2.3.1 torchvision==0.18.1 torchaudio==2.3.1 cudatoolkit=11.8 pytorch-cuda=11.8 -c pytorch -c nvidia

pip install PyYAML

pip install easydict

conda install -y cython

pip install opencv-python

conda install -y pandas

conda install -y tqdm

pip install pycocotools

pip install jpeg4py

conda install -y scipy

pip install timm==0.5.4

pip install tb-nightly

pip install lmdb

pip install visdom

pip install vot-toolkit==0.6.1
